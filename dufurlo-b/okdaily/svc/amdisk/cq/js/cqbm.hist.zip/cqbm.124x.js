//mailmerg.htm JChoy 1/9/00
//uses CQ (Client Side Cgi Query Processing) technology
//4-12-00  JChoy  v0.52 http/edit
//4-16-00  JChoy  v0.53 no alert
//5-09-00  JChoy  v0.54 object, default noEdit
//9-25-00  JChoy  v0.56 multiline
//12-8-00  JChoy  v0.57 ie compatibility for noCR
//5-15-01  JChoy  v0.58 strip oksumbit (was needed for multiline)
//11-17-01 JChoy  v1.21 focus
//3-5-02  JChoy  v1.23 changed stripPlus to preserver real pluses
//11-22-04 JChoy v.24 okBase.callerAttr

function OkBase(o){
	this.version= "_ok v0.59 (c)2004 JChoy";
	this.devUrl= "http://developer.ok88.com";
	var at= document.getElementsByTagName('script'); 
	this.tag= at[at.length-1];
	this.dw= function(s){document.write(s)}
	this.getAttr= function(o,tag,def){	var va= o.attributes[tag]; return (va)? va.value : def;}
	this.callerAttr= function(nm){ return this.getAttr( this.tag, nm, '');}
	this.map= function(d,a,f){ var r=new Array(d.length); for (var i=0; i<d.length; i++)r[i]=f(d[i],i,a); return r}
	this.methLink= function(s,f,params){ return s.link("javascript:"+this.id+"."+f+"("+params+")") }
	this.cgi= function(k){return (location.search+"&"+k+"=").split(k+"=")[1].split("&")[0];}
	this.cgiRemove= function(k){var at=(location.search+"").split(k+"="); if (at.length==1) return at[0]; var k=at[1].indexOf("&"); return (k<0)? at[0] : (at[0]+at[1].substr(k));}
	this.setId= function(id){ this.id=id+"_"+document.links.length; eval(this.id+"=this"); }
	this.subClass= function(o){ for(m in this)o.prototype[m]=this[m] }
} var okBase= new OkBase();


function dw(s){ document.write(s) }
//----------
//object container to hold common variables
function FieldControl() {
	this.inputsize= 50
	this.fieldNames= new Array()
	this.displayType= 'data'	//data,link,both
	this.editText= '<FONT SIZE=-1><I>(click here to make changes)</I></FONT>'
	this.editBothText= '<FONT SIZE=-1>edit</FONT>'
	this.fixPluses= function(){
		if (cgi.locationCgi.indexOf("+")<0) return;
		for (var i=0; i<cgi.arrayCgi.length; i++)
			cgi.arrayCgi[i]= cgi.arrayCgi[i].myReplace("+","%20");
	}
}
okBase.subClass(FieldControl);

//----------
//finish the job for unescape()
String.prototype.myReplace= function(old,nu){return this.split(old).join(nu);}

//---------- 
//create a named cq field
function field(s) {
	var sOut = cgi.value(s)
	fieldControl.fieldNames[fieldControl.fieldNames.length]=s;
	if (sOut==''){
		sOut= fieldControl.callerAttr(s);
	}
	if (sOut=='') {
		//empty field
		dw( '<A HREF='+ cgi.locationBare + '?showform='+s +'&'+cgi.locationCgi +'>' )
		dw( fieldControl.editText +'</A>' )
	} else if (fieldControl.displayType=='link'){	//http-click navs
		dw( sOut.link(sOut) );
	} else if (fieldControl.displayType=='data'){	//text-click edits
		dw( '<A HREF='+cgi.locationBare + '?showform='+s +'&'+cgi.locationCgi )
		dw( '>' +sOut +'</A>' )
	} else if (fieldControl.displayType=='both'){	//http-click navs or edits
		dw( sOut.link(sOut) );
		dw( ' <A HREF='+cgi.locationBare + '?showform='+s +'&'+cgi.locationCgi )
		dw( '>'+fieldControl.editBothText+'</A>' )
	}
}

//----------
function showForm(){
  var editField = cgi.value('showform') 
  var arrayFields= cgi.arrayCgi
  if (editField != '') {
	dw( '<FORM NAME=cqbm ONSUBMIT=return(this.okSubmit.value=="OK")>' )
	var fieldValue= ''+ cgi.value(editField);
	fieldValue= fieldValue.myReplace('"','\'') 
	if (editField.charAt(0)=='_') {
	  dw( '<BR>' +editField +': <BR><TEXTAREA NAME="'+ editField )
	  dw( '" COLS=' +fieldControl.inputsize )
	  dw( ' WRAP=virtual ROWS=6>' +fieldValue +'</TEXTAREA>' )
	} else {
	  dw( '<BR>' +editField +': <INPUT NAME="'+ editField )
	  dw( '" SIZE=' +fieldControl.inputsize +' VALUE="' )
	  dw( fieldValue +'">' )
	}

	for (var i=0; i<arrayFields.length; i++) {
	  var aPair= unescape(arrayFields[i]).split('=')
	  if (aPair[0]=='showform') {
	  } else if (aPair[0]=='undefined') {
	  } else if (aPair[0]=='okSubmit') {
	  } else if (aPair[0]==editField) {
	  } else {
	    dw( '<INPUT TYPE=hidden NAME="'+ aPair[0] +'" VALUE="' )
	    dw( cgi.value(aPair[0]).myReplace('"','\'') +'">' )
	  }
	}
	dw( '<INPUT TYPE=hidden NAME=okSubmit>' )
	dw( '<BR><INPUT TYPE=button VALUE=Submit ONCLICK="this.form.okSubmit.value=\'OK\';this.form.submit()">' )
	dw( ' <INPUT TYPE=reset >' )
	dw( '</FORM><HR>' )
	onload= function(){ document.cqbm.elements[0].focus() }
  }
}

//-----
//create a page that can be saved to disk
//this is deprecated, use tellafriend.js instead (save to email)
function dosave(){
	w=window.open(cgi.locationBare,"")
	var sout = '';
	sout+= '<TITLE>Save CQ Document</TITLE>'
	sout+= '<A HREF="'+document.location +'">View/Edit '
	sout+= document.title +'</A><BR>'
	sout+= 'Click File-Save to save this document to hard disk.<BR>'
	w.document.writeln( sout )
	w.document.close()
	w.document.writeln( sout )
	w.document.close()
}
var fieldControl= new FieldControl();
fieldControl.fixPluses();
function convert2Edit(){}

showForm()
