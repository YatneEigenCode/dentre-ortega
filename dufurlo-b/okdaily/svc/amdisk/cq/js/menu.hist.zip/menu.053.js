//Copyright 2000 Johnston Choy, OK88 LLC 
//http://www.ok88.com http://www.okdaily.com
//License Agreement: GNU General  Public License
//11-21-01 JChoy menu.js v0.52
//11-21-01 JChoy v0.53 lastItemLoaded
function Cgi(s){
	var aT=(s+"?").split("?");
	this.locationBare= aT[0];
	this.aCgi= (aT[1]=="")? []:aT[1].split("&");
	this.id= "cgi";
	this.click= 0;
	this.value= function(s) {
		for (var i=0; i<this.aCgi.length; i++){
			var aKV= this.aCgi[i].split("=");
			if (aKV[0]==s) return unescape(aKV[1]);
		} return "";
	}
	this.dw= function(s){document.write(s)}
}
var cgi=new Cgi(location);

function HotCookie(){
    this.aCookie= document.cookie.split(';')
    this.expiry= ";path=/;expires=" +(new Date((new Date()).valueOf()+31*86400000)).toGMTString();
    this.getCookie= function(key){
        for (var i=0; i<this.aCookie.length; i++){
            aTmp= this.aCookie[i].split('=');
            if ((aTmp[0]==key) || (aTmp[0]==' '+key)) return aTmp[1];
        } return '';
    }//function
    this.setCookie= function(key,value){ document.cookie= key+"="+value+this.expiry; }
}
var hc=new HotCookie;

function about10(msg){
	var lsW= [window.screenX,window.screenY,window.outerWidth,window.outerHeight];
	var lsP= [lsW[0]+lsW[2]/4,lsW[1]+lsW[3]/4,lsW[2]/2,lsW[3]/2];
	var ac= "&timer=10&=Close="+escape("javascript:window.close()");
	var features= "resizable=1,scrollbars=1,location=0,width="+lsP[2]+",height="+lsP[3]+",screenX="+lsP[0]+",screenY="+lsP[1];
	window.open("cqoutofl.htm?="+escape(msg)+ac,"About",features);
}

Cgi.prototype.lastItemLoaded= function(){ 
	var result= ""; 
	for (var i=0; i<this.aCgi.length; i++) {
		var aKV= this.aCgi[i].split("=");
		result+= aKV[0].link(unescape(aKV[1])) +" | ";
	}
	this.dw(result);
}
Cgi.prototype.additem= function(key,val){ 
	this.aCgi[this.aCgi.length]= key +"="+ escape(val);
	var len= parseInt(hc.getCookie("lastItem"));
	if (isNaN(len)) {
	} else if (this.aCgi.length>=len) this.lastItemLoaded();
	setTimeout("hc.setCookie('lastItem','"+this.aCgi.length+"')",5000);
}
var dat=new Cgi("");
dat.additem("Home","javascript:home()");
dat.additem("Menu","menu.html");
//recent
dat.additem("Save","cqoutofl.htm?=To%20save%20changes%20to%20CQ%20documents%2C%20just%20create%20a%20bookmark%20or%20drag%20icon%20into%20folder.");
dat.additem("Reload","javascript:location.reload(true)");
dat.additem("Back","javascript:history.back()");
dat.additem("About","javascript:about()");
