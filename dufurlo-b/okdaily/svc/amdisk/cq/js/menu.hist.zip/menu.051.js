function Cgi(s){
	var aT=(s+"?").split("?");
	this.locationBare= aT[0];
	this.aCgi= aT[1].split("&");
	this.id= "cgi";
	this.click= 0;
	this.value= function(s) {
		for (var i=0; i<this.aCgi.length; i++){
			var aKV= this.aCgi[i].split("=");
			if (aKV[0]==s) return unescape(aKV[1]);
		} return "";
	}
}
var cgi=new Cgi(location);

function about10(msg){
	ac= "&timer=10&=Close="+escape("javascript:window.close()");
	window.open("cqoutofl.htm?="+escape(msg)+this.ac);
}

Cgi.prototype.additem= function(key,val){ 
	this.aCgi[this.aCgi.length]= key +"="+ escape(val);
}
Cgi.prototype.show= function(k){
	var result= ""; 
	for (var i=k; i<this.aCgi.length; i++) {
		var aKV= unescape(this.aCgi[i].split("=")[1]).split("=");
		result+= aKV[0].link(unescape(aKV[1])) +" | ";
	}
	return result;
}
var dat=new Cgi("");
dat.id= "dat";
//home
dat.additem("x","Home=javascript:home()");
//menu
dat.additem("x","Menu=menu.html");
//recent
//save
dat.additem("x","Save="+escape("cqoutofl.htm?=To%20save%20changes%20to%20CQ%20documents%2C%20just%20create%20a%20bookmark%20or%20drag%20icon%20into%20folder."));
//file:///D|/data/h1a/CQ/cqoutofl.htm
//reload
dat.additem("x","Reload=javascript:location.reload(true)");
//back
dat.additem("x","Back=javascript:history.back()");
//about
dat.additem("x","About=javascript:about()");
dw( dat.show(1) );
